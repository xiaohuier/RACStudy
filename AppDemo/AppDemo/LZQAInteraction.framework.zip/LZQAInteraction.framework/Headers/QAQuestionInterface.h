//
//  QAQuestionInterface.h
//  LZQAInteraction
//
//  Created by 周正东 on 2018/1/16.
//  Copyright © 2018年 dingyangyang. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol QAQuestionInterface <NSObject>
//场次ID
@property (nonatomic, copy) NSString *seeeionID;
//问题编号
@property (nonatomic, copy) NSString *questionNumber;
//问题
@property (nonatomic, copy) NSString *question;
//选项
@property (nonatomic, copy) NSArray *options;
//显示题目的时间点
@property (nonatomic, assign) NSTimeInterval showQuestionTimestamp;
//显示后倒计时多少s
@property (nonatomic, assign) NSTimeInterval showTime;
@end
