//
//  QAInteractionApi.h
//  LZQAInteraction
//
//  Created by yang on 2018/1/15.
//  Copyright © 2018年 dingyangyang. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "QARoomInfoInterface.h"
#import "QAInteractionInterface.h"
#import "QAQuestionInterface.h"
#import "QADanmakuInterface.h"

@interface QAInteractionApi : NSObject
/**
 * 设置协议，需要上层实现的功能
 */
+ (void)setAnswerInterface:(id<QAInteractionInterface>)answerInterface;

/**
 * @brief  进入过渡页
 * @param  userId 用户id
 */
+(void)enterAnswerView:(NSInteger)userId;
/**
 * @brief 实时刷新房间信息
 * @param  roomInfo 用户信息
 */
+ (void)refreshRoom:(id<QARoomInfoInterface>)roomInfo;

//获取题目
+ (void)questionsWillshow:(id<QAQuestionInterface>)question;

//获取结果
+ (void)answerJudge:(id<QAQuestionInterface>)question tureCode:(NSInteger)code;

//实时更新播放器的时间
+ (void)palyerTimeDidUpdate:(NSTimeInterval)Timestamp;

/**
 * @brief  实时刷新弹幕信息
 */
+ (void)refreshDanmakuInfo:(id<QADanmakuInterface>)danmakuInfo;


@end
