//
//  QAInteractionInterface.h
//  LZQAInteraction
//
//  Created by yang on 2018/1/15.
//  Copyright © 2018年 dingyangyang. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "QADanmakuInterface.h"

@protocol QAInteractionInterface <NSObject>
/**
 * @brief  播放器
 * @param  playerView 需要播放的view
 */
- (void)answerPlayerWithView:(UIView *)playerView;
/**
 * @brief  停止播放
 */
- (void)stopPlayer;

/**
 * @brief  设置cookie
 * @param  webView 设置的webview
 */
- (void)setCookieWithWebView:(UIWebView *)webView;
/**
 * @brief  登录回调
 */
- (void)loignInSucessCallBack:(id)callBack;

/**
 * @brief  开播提醒:弹框
 */
- (void)allowPlayNotification:(id)callBack;

/**
 * @brief  发送弹幕
 * @param  msg 文本内容[用户id与用户名由主app自行获取]
 */
- (void)sendDanmakuMessage:(NSString *)msg callBack:(id)callBack;

/**答题*/
- (void)answer:(NSDictionary *)params callBack:(void(^)(NSDictionary *resp))block;

/**复活*/
- (void)resurrection:(NSDictionary *)params callBack:(void(^)(NSDictionary *resp))block;

@end


