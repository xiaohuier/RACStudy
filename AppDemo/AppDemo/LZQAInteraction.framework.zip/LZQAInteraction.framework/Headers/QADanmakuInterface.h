//
//  QADanmakuInterface.h
//  LZQAInteraction
//
//  Created by  HYY on 2018/1/16.
//  Copyright © 2018年 dingyangyang. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol QADanmakuInterface <NSObject>
/**
 * @brief  用户id
 */
- (NSInteger)getUserId;

/**
 * @brief  用户名称
 */
- (NSString *)getUserName;

/**
 * @brief  弹幕内容
 */
- (NSString *)getUserMsg;

@end
