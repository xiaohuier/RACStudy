//
//  QARoomInfoInterface.h
//  LZQAInteraction
//
//  Created by yang on 2018/1/15.
//  Copyright © 2018年 dingyangyang. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol QARoomInfoInterface <NSObject>
//房间id
- (NSInteger)getRoomId;

//房间头像
- (UIImage *)getRoomIcon;

//房间标题
- (NSString *)getRoomTitle;

//观看人数
- (NSInteger )getRoomAudienceTotal;

@end
